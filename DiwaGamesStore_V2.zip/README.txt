DiwaGamesStore V2
=================
Edit index.html and find: const games=[ ... ]

For each game change:
name = game name
cat = category
icon = emoji (can be replaced by an image-based card later)
desc = short description
link = your authorized/official game URL

Preview by opening index.html in a browser.
